﻿namespace EmployeeRegistryAPI
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string ErrorMessage { get; set; }
    }
}

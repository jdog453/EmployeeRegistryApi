﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace EmployeeRegistryAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        public EmployeesController (IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetEmployees")]
        public string GetEmployees()
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("EmployeeInfoCon").ToString());
            SqlDataAdapter da = new SqlDataAdapter("Select * FROM EmployeeInformation", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<Employee> employeeList = new List<Employee>();
            Response response = new Response();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Employee employee = new Employee();
                    employee.PersonalID = Convert.ToInt32(dt.Rows[i]["PersonalID"]);
                    employee.FirstName = dt.Rows[i]["FirstName"].ToString();
                    employee.LastName = dt.Rows[i]["LastName"].ToString();
                    employee.Email = dt.Rows[i]["EmailAddress"].ToString();
                    employee.Date = Convert.ToDateTime(dt.Rows[i]["HiredDate"]);
                    employee.JobTitle = dt.Rows[i]["JobTitle"].ToString();
                    if (!dt.Rows[i]["AgencyNumber"].Equals(System.DBNull.Value))
                    {
                        employee.AgencyNumber = Convert.ToInt32(dt.Rows[i]["AgencyNumber"]);
                    }
                    else
                    {
                        employee.AgencyNumber = null;
                    }
                    employeeList.Add(employee);
                }
            }
            if (employeeList.Count > 0)
            {
                return JsonConvert.SerializeObject(employeeList);
            }
            else
            {
                response.StatusCode = 100;
                response.ErrorMessage = "No data found";
                return JsonConvert.SerializeObject(response);
            }
        }

        [HttpPost]
        [Route("AddEmployees")]
        public void AddEmployees(Employee employee)
        {
            System.Diagnostics.Debug.Write(employee);
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("EmployeeInfoCon").ToString());
            con.Open();
            string query = "BEGIN IF NOT EXISTS (SELECT * FROM EmployeeInformation WHERE [PersonalID] = " + Convert.ToInt32(employee.PersonalID) + ") BEGIN INSERT INTO EmployeeInformation ([PersonalID], [FirstName], [LastName], [EmailAddress], [HiredDate], [JobTitle], [AgencyNumber]) VALUES ('" + Convert.ToInt32(employee.PersonalID) + "', '" + employee.FirstName + "', '" + employee.LastName + "', '" + employee.Email + "', '" + employee.Date + "', '" + employee.JobTitle + "', '" + Convert.ToInt32(employee.AgencyNumber) + "') END END";
            SqlCommand com = new SqlCommand(query, con);
            com.ExecuteNonQuery();
            con.Close();
        }
    }
}

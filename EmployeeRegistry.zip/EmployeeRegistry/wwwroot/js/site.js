﻿$(document).ready(function () {

    var employees = [];

    $.ajax({
        
        url: "https://localhost:44324/api/Employees/GetEmployees",
        method: "GET",
        success: function (res) {
            var tableString = "";
            var tableHeaders = "";
            tableHeaders = "<tr><th padding=10px>Personal ID</th><th padding=10px>First Name</th><th padding=10px>Last Name</th><th padding=10px>Email</th><th padding=10px>Hired Date</th><th padding=10px>Job Title</th><th padding=10px>Agency Number</th><th></th><th></th></tr>";
            $('#employeeTable').append(tableHeaders);
            $.each(JSON.parse(res), function (index, value) {
                employees.push(value);
                //console.log(value);
                var hired = new Date(value.Date).toLocaleDateString();
                if (value.AgencyNumber == 0 || value.AgencyNumber == null) {
                    tableString += "<tr><td padding=10px>" + value.PersonalID + "</td><td padding=10px>" + value.FirstName + "</td><td padding=10px>" + value.LastName + "</td><td padding=10px>" + value.Email + "</td><td padding=10px>" + hired + "</td><td padding=10px>" + value.JobTitle + "</td><td padding=10px></td><td padding=10px><button type='button' class='edit' title='edit'>Edit</button></td><td><button class='delete' name='delete'>Delete</button></td></tr>";
                }
                else {
                    tableString += "<tr><td padding=10px>" + value.PersonalID + "</td><td padding=10px>" + value.FirstName + "</td><td padding=10px>" + value.LastName + "</td><td padding=10px>" + value.Email + "</td><td padding=10px>" + hired + "</td><td padding=10px>" + value.JobTitle + "</td><td padding=10px>" + value.AgencyNumber + "</td><td padding=10px><button type='button' class='edit' title='edit'>Edit</button></td><td><button class='delete' name='delete'>Delete</button></td></tr>"; 
                }
            });
            $('#employeeTable').append(tableString);
        },
        error: function (error) {
            console.log(error);
        }
    });  

    var insertModal = document.getElementById('insertModal');
    var editModal = document.getElementById('editModal');
    var span = document.getElementsByClassName("close")[0];
    var editSpan = document.getElementsByClassName("close")[1];
    var insertSaveNew = document.getElementById('saveNew');

    document.getElementById('hiredDate').max = new Date().toISOString().split("T")[0];

    document.getElementById('insert').onclick = function () {
        openInsertModal();
    }

    $('body').on('click', '.edit', function () {
        var $row = $(this).closest("tr"),
            $tdPid = $row.find("td:nth-child(1)"),
            $tdfn = $row.find("td:nth-child(2)"),
            $tdln = $row.find("td:nth-child(3)"),
            $tdemail = $row.find("td:nth-child(4)"),
            $tddate = $row.find("td:nth-child(5)"),
            $tdjobtitle = $row.find("td:nth-child(6)"),
            $tdanum = $row.find("td:nth-child(7)");
        
        $('#editPersonalIDInput').val($tdPid[0].innerHTML);
        $('#editFirstNameInput').val($tdfn[0].innerHTML);
        $('#editLastNameInput').val($tdln[0].innerHTML);
        $('#editEmailInput').val($tdemail[0].innerHTML);
        var date = new Date($tddate[0].innerHTML);
        var dateStrings = getHTML5DateStringsFromDate(date);
        $('#editHiredDate').val(dateStrings[0]);
        $('#editJobTitle').val($tdjobtitle[0].innerHTML);
        $('#editAgencyNum').val($tdanum[0].innerHTML);
        editJobSelect();
        editModal.style.display = "block";
    });

    document.getElementById('jobTitle').onchange = function () {
        jobSelect();
    };

    document.getElementById('editJobTitle').onchange = function () {
        editJobSelect();
    };

    span.onclick = function () {
        if (insertModal.style.display == "block") {
            insertModal.style.display = "none";
        }
    }

    editSpan.onclick = function () {
        if (editModal.style.display == "block") {
            editModal.style.display = "none";
        }
    }

    window.onclick = function (event) {
        if (event.target == insertModal) {
            insertModal.style.display = "none";
        }
        if (event.target == editModal) {
            editModal.style.display = "none";
        }
    }

    insertSaveNew.onclick = function () {
        var newPID = $('#personalIDInput')[0].value;
        var newFName = $('#firstNameInput')[0].value;
        var newLName = $('#lastNameInput')[0].value;
        var newEmail = $('#emailInput')[0].value;
        var newHiredDate = $('#hiredDate')[0].value;
        var newTitle = $('#jobTitle')[0].value;
        var newAgencyNum = $('#agencyNum')[0].value;

        saveEmployee(newPID, newFName, newLName, newEmail, newHiredDate, newTitle, newAgencyNum);
    }

    function getHTML5DateStringsFromDate(d) {
        var ds = d.getFullYear().toString().padStart(4, '0') + '-' + (d.getMonth() + 1).toString().padStart(2, '0') + '-' + d.getDate().toString().padStart(2, '0');

        return [ds];
    }

    function openInsertModal() {
        insertModal.style.display = "block";
    }

    function jobSelect() {
        var d = document.getElementById("jobTitle");
        var title = d.options[d.selectedIndex].text;
        if (title != "Direct Rep A" && title != "Direct Rep B") {
            document.getElementById("agencyNumLabel").classList.add("hidden");
            document.getElementById("agencyNum").classList.add("hidden");
        }
        else {
            document.getElementById("agencyNumLabel").classList.remove("hidden");
            document.getElementById("agencyNum").classList.remove("hidden");
        }
    }

    function editJobSelect() {
        var d = document.getElementById("editJobTitle");
        var title = d.options[d.selectedIndex].text;
        if (title != "Direct Rep A" && title != "Direct Rep B") {
            document.getElementById("editAgencyNumLabel").classList.add("hidden");
            document.getElementById("editAgencyNum").classList.add("hidden");
        }
        else {
            document.getElementById("editAgencyNumLabel").classList.remove("hidden");
            document.getElementById("editAgencyNum").classList.remove("hidden");
        }
    }

    function saveEmployee(id, fname, lname, email, date, jobTitle, agencyNum) {
        console.log(id);
        console.log(fname);
        console.log(lname);
        console.log(email);
        console.log(date);
        console.log(jobTitle);
        console.log(agencyNum);
        var hired = new Date(date);
        console.log(hired);

        var employee = {
            "employee": {
                "PersonalID": id,
                "FirstName": fname,
                "LastName": lname,
                "Email": email,
                "Date": hired,
                "JobTitle": jobTitle,
                "AgencyNumber": agencyNum
            }
        };
        console.log(employee);
        var data = JSON.stringify({ 'employee': employee });

        $.ajax({
            url: "https://localhost:44324/api/Employees/AddEmployees",
            method: "POST",
            async: true,
            contentType: "application/json; charset=utf-8",
            dataType: "json", 
            data: JSON.stringify({
                "employee": employee
            }),                       
            success: function (res) {
                console.log("Success");
                location.reload(true);
            },
            error: function (error) {
                console.log(error);
            }
        });
    }

    (function () {
            $('form input').on("keyup change", function () {
                var empty = false;
                $('form input').each(function () {
                    if ($(this).val() == '') {
                        empty = true;
                    }
                });

                if (empty) {
                    if ($('#jobTitle').val() == 'TA Rep A' || $('#jobTitle').val() == 'TA Rep B') {
                        var pID = document.getElementById('personalIDInput');
                        var email = document.getElementById('emailInput');

                        $('#personalIDInput').on('paste keydown keyup input', function () {
                            pID = document.getElementById('personalIDInput');
                        });
                        $('#emailInput').on('paste keydown keyup input', function () {
                            email = document.getElementById('emailInput');
                        });

                        if (pID.value.length == 7 && email.validity.valid) {
                            $('#saveNew').removeAttr('disabled');
                        }
                        else {
                            $('#saveNew').attr('disabled', 'disabled');
                        }
                    }
                    else {
                        $('#saveNew').attr('disabled', 'disabled');
                    }
                }
                else {
                    var pID = document.getElementById('personalIDInput');
                    var email = document.getElementById('emailInput');

                    $('#personalIDInput').on('paste keydown keyup input', function () {
                        pID = document.getElementById('personalIDInput');
                    });
                    $('#emailInput').on('paste keydown keyup input', function () {
                        email = document.getElementById('emailInput');
                    });

                    if (pID.value.length == 7 && email.validity.valid) {
                        $('#saveNew').removeAttr('disabled');
                    }
                    else {
                        $('#saveNew').attr('disabled', 'disabled');
                    }
                }
            });
            $('form input').on("keyup change", function () {
                var empty = false;
                $('form input').each(function () {
                    if ($(this).val() == '') {
                        empty = true;
                    }
                });

                if (empty) {
                    if ($('#editJobTitle').val() == 'TA Rep A' || $('#editJobTitle').val() == 'TA Rep B') {
                        var editPID = document.getElementById('editPersonalIDInput');
                        var editEmail = document.getElementById('editEmailInput');

                        $('#editPersonalIDInput').on('paste keydown keyup input', function () {
                            editPID = document.getElementById('editPersonalIDInput');
                        });
                        $('#editEmailInput').on('paste keydown keyup input', function () {
                            editEmail = document.getElementById('editEmailInput');
                        });

                        if (editPID.value.length == 7 && editEmail.validity.valid) {
                            $('#editSaveNew').removeAttr('disabled');
                        }
                        else {
                            $('#editSaveNew').attr('disabled', 'disabled');
                        }
                    }
                    else if (($('#editJobTitle').val() == 'Direct Rep A' || $('#editJobTitle').val() == 'Direct Rep B') && $('#editAgencyNumber').val() != "") {
                        var editPID = document.getElementById('editPersonalIDInput');
                        var editEmail = document.getElementById('editEmailInput');

                        $('#editPersonalIDInput').on('paste keydown keyup input', function () {
                            editPID = document.getElementById('editPersonalIDInput');
                        });
                        $('#editEmailInput').on('paste keydown keyup input', function () {
                            editEmail = document.getElementById('editEmailInput');
                        });

                        if (editPID.value.length == 7 && editEmail.validity.valid) {
                            $('#editSaveNew').removeAttr('disabled');
                        }
                        else {
                            $('#editSaveNew').attr('disabled', 'disabled');
                        }
                    }
                    else {
                        $('#editSaveNew').attr('disabled', 'disabled');
                    }
                }
                else {
                    console.log("Made it nothing was empty");
                    var editPID = document.getElementById('editPersonalIDInput');
                    var editEmail = document.getElementById('editEmailInput');

                    $('#editPersonalIDInput').on('paste keydown keyup input', function () {
                        editPID = document.getElementById('editPersonalIDInput');
                    });
                    $('#editEmailInput').on('paste keydown keyup input', function () {
                        editEmail = document.getElementById('editEmailInput');
                    });

                    if (editPID.value.length == 7 && editEmail.validity.valid) {
                        $('#editSaveNew').removeAttr('disabled');
                    }
                    else {
                        $('#editSaveNew').attr('disabled', 'disabled');
                    }
                }
            });
    })()
});